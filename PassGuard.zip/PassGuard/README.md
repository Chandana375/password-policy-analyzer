# 🔐 PassGuard — Password Policy Analyzer
> Project 5 of 10 | Author: Chiranth S | CEH

## Run It
```powershell
cd "$env:USERPROFILE\Downloads\PassGuard\backend"
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```
Open: `frontend\index.html`

## Features
- Real-time password strength analyzer
- Shannon entropy calculator
- NIST SP 800-63B, PCI-DSS 4.0, ISO 27001, HIPAA compliance
- Crack time estimation (online, bcrypt, GPU)
- Password generator with passphrase mode
- Policy builder — generates full GRC policy document
- Bulk audit — analyze up to 100 passwords at once
- Works fully offline (no backend needed)
