"""
PassGuard - Password Policy Analyzer & GRC Compliance Tool
Author: Chiranth S | CEH | Cybersecurity Suite Project 5
"""

import re
import math
import json
from datetime import datetime, timezone
from typing import Optional, List
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="PassGuard API", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# ── Top 100 most common passwords ─────────────────────────────────────────────
COMMON_PASSWORDS = {
    "password","123456","12345678","qwerty","abc123","monkey","1234567",
    "letmein","trustno1","dragon","baseball","iloveyou","master","sunshine",
    "ashley","bailey","passw0rd","shadow","123123","654321","superman",
    "qazwsx","michael","football","password1","password123","admin","admin123",
    "welcome","login","solo","princess","azerty","starwars","hello","charlie",
    "donald","password2","qwerty123","696969","batman","access","mustang",
    "hello123","thomas","robert","hunter","ranger","buster","tigger","soccer",
    "hockey","killer","george","andrew","charlie","thomas","hello","aaron",
    "jessica","welcome1","123456789","1234567890","00000000","11111111","pass",
    "pass123","root","toor","test","guest","default","changeme","secret",
    "p@ssw0rd","p@ssword","password!","password1!","qwerty1","abc1234",
    "111111","000000","123321","666666","1234","12345","123456789","1234567890",
    "superman1","batman1","iloveyou1","monkey1","dragon1","master1","sunshine1",
    "princess1","welcome2","password2","login123","admin1234","root123","test123"
}

# ── Models ────────────────────────────────────────────────────────────────────
class PasswordRequest(BaseModel):
    password: str

class BulkRequest(BaseModel):
    passwords: List[str]

class PolicyRequest(BaseModel):
    org_name: str = "Organization"
    standard: str = "nist"
    min_length: int = 12
    max_age_days: int = 90
    history_count: int = 10
    max_attempts: int = 5
    require_upper: bool = True
    require_lower: bool = True
    require_numbers: bool = True
    require_symbols: bool = True
    require_mfa: bool = True

# ── Core Analysis ─────────────────────────────────────────────────────────────

def calculate_entropy(password: str) -> float:
    charset = 0
    if re.search(r'[a-z]', password): charset += 26
    if re.search(r'[A-Z]', password): charset += 26
    if re.search(r'[0-9]', password): charset += 10
    if re.search(r'[^a-zA-Z0-9]', password): charset += 32
    if charset == 0: return 0.0
    return round(len(password) * math.log2(charset), 2)


def estimate_crack_time(password: str) -> dict:
    charset = 0
    if re.search(r'[a-z]', password): charset += 26
    if re.search(r'[A-Z]', password): charset += 26
    if re.search(r'[0-9]', password): charset += 10
    if re.search(r'[^a-zA-Z0-9]', password): charset += 32
    combinations = max(charset ** len(password), 1)

    speeds = {
        "online_throttled": 100,
        "online_unthrottled": 10_000,
        "offline_slow": 10_000_000,
        "offline_fast": 1_000_000_000,
        "offline_gpu": 100_000_000_000,
    }

    def fmt(seconds):
        if seconds < 1: return "Instant"
        if seconds < 60: return f"{int(seconds)} seconds"
        if seconds < 3600: return f"{int(seconds/60)} minutes"
        if seconds < 86400: return f"{int(seconds/3600)} hours"
        if seconds < 2592000: return f"{int(seconds/86400)} days"
        if seconds < 31536000: return f"{int(seconds/2592000)} months"
        if seconds < 3153600000: return f"{int(seconds/31536000)} years"
        if seconds < 315360000000: return f"{int(seconds/31536000/100)*100}+ years"
        return "Centuries+"

    return {k: fmt(combinations / 2 / v) for k, v in speeds.items()}


def check_patterns(password: str) -> dict:
    return {
        "min_length_8":     len(password) >= 8,
        "min_length_12":    len(password) >= 12,
        "min_length_16":    len(password) >= 16,
        "has_uppercase":    bool(re.search(r'[A-Z]', password)),
        "has_lowercase":    bool(re.search(r'[a-z]', password)),
        "has_numbers":      bool(re.search(r'[0-9]', password)),
        "has_symbols":      bool(re.search(r'[^a-zA-Z0-9]', password)),
        "no_common":        password.lower() not in COMMON_PASSWORDS,
        "no_repeating":     not bool(re.search(r'(.)\1{2,}', password)),
        "no_sequential":    not bool(re.search(r'(012|123|234|345|456|567|678|789|890|abc|bcd|cde|def|efg|fgh|ghi|hij|ijk|jkl|klm|lmn|mno|nop|opq|pqr|qrs|rst|stu|tuv|uvw|vwx|wxy|xyz)', password.lower())),
        "no_keyboard_walk": not bool(re.search(r'(qwer|wert|erty|rtyu|tyui|yuio|uiop|asdf|sdfg|dfgh|fghj|ghjk|hjkl|zxcv|xcvb|cvbn|vbnm)', password.lower())),
        "mixed_case":       bool(re.search(r'[A-Z]', password)) and bool(re.search(r'[a-z]', password)),
        "three_plus_types": sum([
            bool(re.search(r'[A-Z]', password)),
            bool(re.search(r'[a-z]', password)),
            bool(re.search(r'[0-9]', password)),
            bool(re.search(r'[^a-zA-Z0-9]', password)),
        ]) >= 3,
    }


def calculate_score(password: str, checks: dict, entropy: float) -> int:
    score = 0
    if len(password) >= 8:  score += 10
    if len(password) >= 12: score += 15
    if len(password) >= 16: score += 10
    if len(password) >= 20: score += 5
    if checks["has_uppercase"]:    score += 8
    if checks["has_lowercase"]:    score += 8
    if checks["has_numbers"]:      score += 8
    if checks["has_symbols"]:      score += 12
    if checks["no_common"]:        score += 10
    if checks["no_repeating"]:     score += 5
    if checks["no_sequential"]:    score += 5
    if checks["no_keyboard_walk"]: score += 4
    if entropy >= 60:  score += 10
    elif entropy >= 40: score += 5
    return min(score, 100)


def get_compliance(password: str, checks: dict) -> dict:
    l = len(password)
    return {
        "nist_800_63b": {
            "name": "NIST SP 800-63B",
            "compliant": l >= 8 and checks["no_common"] and checks["no_repeating"],
            "requirements": [
                {"rule": "Minimum 8 characters", "met": l >= 8},
                {"rule": "Not a commonly used password", "met": checks["no_common"]},
                {"rule": "No repetitive characters (aaa, 111)", "met": checks["no_repeating"]},
                {"rule": "No context-specific words (username, site name)", "met": True},
            ]
        },
        "pci_dss_4": {
            "name": "PCI-DSS 4.0",
            "compliant": l >= 12 and checks["has_numbers"] and checks["has_uppercase"] and checks["has_symbols"],
            "requirements": [
                {"rule": "Minimum 12 characters", "met": l >= 12},
                {"rule": "Contains uppercase letters", "met": checks["has_uppercase"]},
                {"rule": "Contains numeric digits", "met": checks["has_numbers"]},
                {"rule": "Contains special characters", "met": checks["has_symbols"]},
                {"rule": "Change every 90 days", "met": True},
            ]
        },
        "iso_27001": {
            "name": "ISO/IEC 27001",
            "compliant": l >= 12 and checks["three_plus_types"] and checks["no_common"],
            "requirements": [
                {"rule": "Minimum 12 characters", "met": l >= 12},
                {"rule": "3 or more character types", "met": checks["three_plus_types"]},
                {"rule": "Not a dictionary word", "met": checks["no_common"]},
                {"rule": "No personal information", "met": True},
            ]
        },
        "hipaa": {
            "name": "HIPAA Security Rule",
            "compliant": l >= 8 and checks["three_plus_types"],
            "requirements": [
                {"rule": "Minimum 8 characters", "met": l >= 8},
                {"rule": "Mixed character types", "met": checks["three_plus_types"]},
                {"rule": "Automatic logoff enforced", "met": True},
                {"rule": "Audit controls in place", "met": True},
            ]
        },
    }


def get_suggestions(password: str, checks: dict, entropy: float) -> list:
    suggestions = []
    if len(password) < 12:
        suggestions.append("Use at least 12 characters — length is the single most important factor")
    if len(password) < 16:
        suggestions.append("16+ characters makes brute-force attacks practically impossible")
    if not checks["has_uppercase"]:
        suggestions.append("Add uppercase letters (A-Z) to increase character set size")
    if not checks["has_lowercase"]:
        suggestions.append("Add lowercase letters (a-z)")
    if not checks["has_numbers"]:
        suggestions.append("Add numbers (0-9)")
    if not checks["has_symbols"]:
        suggestions.append("Add symbols like !@#$%^&* for maximum strength")
    if not checks["no_common"]:
        suggestions.append("This is a commonly known password — choose something unique")
    if not checks["no_repeating"]:
        suggestions.append("Avoid repeating characters like 'aaa' or '111'")
    if not checks["no_sequential"]:
        suggestions.append("Avoid sequential patterns like 'abc' or '123'")
    if not checks["no_keyboard_walk"]:
        suggestions.append("Avoid keyboard walk patterns like 'qwerty' or 'asdf'")
    if entropy < 50:
        suggestions.append(f"Entropy is {entropy} bits — aim for 60+ bits for a strong password")
    if len(password) >= 16 and checks["three_plus_types"] and checks["no_common"]:
        suggestions.append("Consider using a passphrase: 4 random words are strong and memorable (e.g. correct-horse-battery-staple)")
    return suggestions


def get_strength_label(score: int) -> str:
    if score >= 85: return "Very Strong"
    if score >= 70: return "Strong"
    if score >= 50: return "Moderate"
    if score >= 30: return "Weak"
    return "Very Weak"


# ── Routes ────────────────────────────────────────────────────────────────────

@app.get("/health")
def health():
    return {"status": "ok", "version": "1.0.0", "timestamp": datetime.now(timezone.utc).isoformat()}


@app.post("/password/analyze")
def analyze_password(req: PasswordRequest):
    pw = req.password
    if len(pw) > 256:
        raise HTTPException(status_code=400, detail="Password too long (max 256 chars)")

    checks     = check_patterns(pw)
    entropy    = calculate_entropy(pw)
    score      = calculate_score(pw, checks, entropy)
    crack      = estimate_crack_time(pw)
    compliance = get_compliance(pw, checks)
    suggestions= get_suggestions(pw, checks, entropy)

    return {
        "length":       len(pw),
        "score":        score,
        "strength":     get_strength_label(score),
        "entropy":      entropy,
        "is_common":    pw.lower() in COMMON_PASSWORDS,
        "checks":       checks,
        "crack_times":  crack,
        "compliance":   compliance,
        "suggestions":  suggestions,
        "analyzed_at":  datetime.now(timezone.utc).isoformat()
    }


@app.post("/password/bulk")
def bulk_analyze(req: BulkRequest):
    if len(req.passwords) > 100:
        raise HTTPException(status_code=400, detail="Max 100 passwords per request")

    results = []
    for pw in req.passwords:
        pw = pw.strip()
        if not pw:
            continue
        checks  = check_patterns(pw)
        entropy = calculate_entropy(pw)
        score   = calculate_score(pw, checks, entropy)
        results.append({
            "password":   pw[:3] + "*" * max(0, len(pw)-3),  # mask for privacy
            "score":      score,
            "strength":   get_strength_label(score),
            "entropy":    entropy,
            "is_common":  pw.lower() in COMMON_PASSWORDS,
            "length":     len(pw),
        })

    results.sort(key=lambda x: x["score"])
    total    = len(results)
    strong   = sum(1 for r in results if r["score"] >= 70)
    moderate = sum(1 for r in results if 50 <= r["score"] < 70)
    weak     = sum(1 for r in results if r["score"] < 50)

    return {
        "total":    total,
        "strong":   strong,
        "moderate": moderate,
        "weak":     weak,
        "results":  results
    }


@app.post("/policy/generate")
def generate_policy(req: PolicyRequest):
    date = datetime.now(timezone.utc).strftime("%B %d, %Y")
    std  = req.standard.upper().replace("_", " ")

    complexity = []
    if req.require_upper:   complexity.append("uppercase letters (A-Z)")
    if req.require_lower:   complexity.append("lowercase letters (a-z)")
    if req.require_numbers: complexity.append("numeric digits (0-9)")
    if req.require_symbols: complexity.append("special characters (!@#$%^&*)")

    policy_text = f"""PASSWORD SECURITY POLICY
{'='*60}
Organization : {req.org_name}
Standard     : {std}
Effective    : {date}
Version      : 1.0
{'='*60}

1. PURPOSE
   This policy establishes minimum requirements for password
   creation, management, and protection to safeguard
   {req.org_name} information systems and comply with
   {std} requirements.

2. SCOPE
   Applies to all employees, contractors, vendors, and any
   individual with access to {req.org_name} systems.

3. PASSWORD REQUIREMENTS

   3.1 Minimum Length
       All passwords must be at least {req.min_length} characters.
       Passwords of 16+ characters are strongly encouraged.

   3.2 Character Complexity
       {'chr(10)+'+'       '.join(['✓ Must contain '+c for c in complexity]) if complexity else '       ○ No complexity requirements (NIST recommendation)'}
       ✓ Must not be a commonly used or breached password
       ✓ Must not contain the user name or account name
       ✓ Must not use sequential patterns (abc, 123, qwerty)

   3.3 Password Expiry
       {'Passwords must be changed every '+str(req.max_age_days)+' days.' if req.max_age_days > 0 else 'No mandatory expiry period (per NIST SP 800-63B).'}
       {'Users receive advance warning 14 days before expiry.' if req.max_age_days > 0 else 'Passwords are changed when compromise is suspected.'}

   3.4 Password History
       {'The system will retain the last '+str(req.history_count)+' passwords.' if req.history_count > 0 else 'No password history requirement.'}
       {'Users may not reuse any of their previous '+str(req.history_count)+' passwords.' if req.history_count > 0 else ''}

   3.5 Account Lockout
       Accounts lock after {req.max_attempts} consecutive failed attempts.
       Locked accounts require administrator intervention.
       Lockout duration: minimum 30 minutes.

4. MULTI-FACTOR AUTHENTICATION
   {'✓ MFA is MANDATORY for all user accounts.' if req.require_mfa else '○ MFA is recommended but not currently required.'}
   {'   Acceptable MFA: authenticator app, hardware token, FIDO2.' if req.require_mfa else ''}
   {'   SMS-based MFA is permitted but not recommended.' if req.require_mfa else ''}

5. PASSWORD STORAGE
   ✓ Passwords must NEVER be stored in plaintext
   ✓ Use bcrypt (cost ≥12), Argon2id, or PBKDF2-SHA256
   ✓ Each password must use a unique cryptographic salt
   ✓ Password hashes must not be transmitted over networks

6. PASSWORD HANDLING
   ✗ Password sharing between users is strictly prohibited
   ✗ Passwords must not be transmitted via email or chat
   ✗ Passwords must not be written down or stored in notes
   ✓ Use an approved corporate password manager
   ✓ Report suspected password compromise immediately

7. PRIVILEGED ACCOUNTS
   ✓ Admin/service accounts require passwords of 20+ chars
   ✓ Privileged accounts require MFA without exception
   ✓ Service account passwords rotated every 90 days
   ✓ All privileged access logged and audited

8. ENFORCEMENT
   Violations may result in disciplinary action up to and
   including termination or contract cancellation.
   IT Security team conducts quarterly compliance audits.

{'='*60}
Approved by  : ________________________  Date: {date}
Reviewed by  : IT Security Team
Next Review  : {datetime.now(timezone.utc).replace(year=datetime.now(timezone.utc).year+1).strftime('%B %d, %Y')}
References   : {std} | NIST SP 800-63B | CIS Controls v8
{'='*60}"""

    return {
        "policy_text": policy_text,
        "standard":    req.standard,
        "org_name":    req.org_name,
        "generated_at":datetime.now(timezone.utc).isoformat()
    }


@app.get("/common/check/{password}")
def check_common(password: str):
    return {
        "password": password[:3] + "***",
        "is_common": password.lower() in COMMON_PASSWORDS,
        "common_count": len(COMMON_PASSWORDS)
    }
